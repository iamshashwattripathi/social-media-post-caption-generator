import gradio as gr
from transformers import pipeline
import random

# Load GPT-2 model for caption generation
caption_generator = pipeline("text-generation", model="gpt2")

# Emoji dictionary
emoji_dict = {
    "positive": ["😊", "😄", "🔥", "💪", "🌟", "🎉"],
    "negative": ["😢", "😔", "💔", "😞", "😩"],
    "neutral": ["🤔", "😐", "🧐"]
}

# Sentiment analysis pipeline
sentiment_pipeline = pipeline("sentiment-analysis")

# Function to get emojis based on sentiment
def get_emojis(text):
    label = sentiment_pipeline(text)[0]['label'].lower()
    return ''.join(random.sample(emoji_dict.get(label, ["🤔"]), 3))

# Function to get hashtags based on input and platform
def get_hashtags(prompt, platform):
    words = prompt.lower().split()
    tags = ["#" + word.replace(" ", "") for word in words if len(word) > 3]

    platform_tags = {
        "Instagram": ["#instadaily", "#igers", "#picoftheday"],
        "LinkedIn": ["#career", "#leadership", "#networking"],
        "Twitter": ["#tweet", "#trending", "#news"]
    }

    return " ".join(tags[:5] + random.sample(platform_tags[platform], 2))

# Core function to generate post
def generate_post(prompt, platform):
    caption = caption_generator(prompt, max_length=50, num_return_sequences=1)[0]['generated_text']
    emojis = get_emojis(caption)
    hashtags = get_hashtags(prompt, platform)
    return caption.strip(), emojis, hashtags

# Gradio Interface
interface = gr.Interface(
    fn=generate_post,
    inputs=[
        gr.Textbox(label="Enter keyword or theme"),
        gr.Radio(["Instagram", "LinkedIn", "Twitter"], label="Choose Platform")
    ],
    outputs=[
        gr.Textbox(label="Generated Caption"),
        gr.Textbox(label="Emojis"),
        gr.Textbox(label="Hashtags")
    ],
    title="Social Media Post & Caption Generator",
    description="Generate catchy captions, relevant hashtags, and emojis based on your theme!"
)

interface.launch()
