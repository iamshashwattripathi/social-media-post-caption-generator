# Social Media Post & Caption Generator 📝✨

An AI-powered tool that generates engaging social media posts including captions, emojis, and hashtags based on your input and platform preference.

## Features
- Automatically generates captions using GPT-2
- Detects sentiment and adds fitting emojis
- Suggests platform-specific hashtags
- User-friendly Gradio interface
- Works on Instagram, LinkedIn, and Twitter

## Technologies Used
- Python
- Hugging Face Transformers
- Gradio
- Sentiment Analysis

## How to Run
1. Clone the repository
2. Install dependencies:
```bash
pip install -r requirements.txt
```
3. Run the app:
```bash
python app.py
```
Then open the URL shown in your terminal.

## Author
Shashwat Tripathi
